import pandas as pd

# CSV 파일 불러오기
df1 = pd.read_csv("서울_지구대주소.csv", encoding="utf-8")  # 기준 데이터
df2 = pd.read_csv("서울_치안센터_주소.csv", encoding="euc-kr")  # 추가할 데이터

# df2의 컬럼명을 df1의 컬럼명과 동일하게 변경
df2.columns = df1.columns

# 두 데이터프레임을 수직 결합
merged_df = pd.concat([df1, df2], ignore_index=True)

# '주소' 컬럼 삭제
merged_df = merged_df.drop(columns=['주소'])

# 변경된 데이터프레임을 CSV 파일로 저장
output_file = "통합_서울_치안센터_주소.csv"

with open(output_file, mode="w", encoding="utf-8", newline="") as file:
    merged_df.to_csv(file, index=False)

print(f"파일이 성공적으로 저장되었습니다: {output_file}")