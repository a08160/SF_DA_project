import pandas as pd

# 
file_name = "서울_지구대주소.csv"
df = pd.read_csv(file_name, encoding="utf-8")

# 'Unnamed' 컬럼명을 '행정동'으로 변경
df = df.rename(columns={'Unnamed: 5': '행정동'})

# 변경된 데이터프레임을 CSV 파일로 저장
output_file = "수정_서울_지구대주소.csv"

with open(output_file, mode="w", encoding="utf-8", newline="") as file:
    df.to_csv(file, index=False)

print(f"파일이 성공적으로 저장되었습니다: {output_file}")