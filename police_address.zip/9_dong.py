import pandas as pd

# CSV 파일 불러오기
df = pd.read_csv("찐찐통합_행정동별_치안센터.csv", encoding="utf-8")

# "상일1동"이 포함된 행 제거
df = df[df["행정동"] != "서울특별시 강동구 상일1동"]

# 인덱스를 다시 설정
df = df.reset_index(drop=True)

# 변경된 데이터프레임을 새로운 CSV 파일로 저장
file_name = "리얼찐통합_행정동별_치안센터_수정.csv"
with open(file_name, mode="w", encoding="utf-8", newline="") as file:
    df.to_csv(file, index=False)

print(f"'{file_name}' 파일이 저장되었습니다.")