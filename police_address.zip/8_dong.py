import pandas as pd

# CSV 파일 불러오기
df = pd.read_csv("행정동별_치안센터.csv", encoding="utf-8")
dong_df = pd.read_csv("dong_info.csv", encoding="utf-8")

# df와 dong_df에서 "행정동"과 "adm_nm"을 비교하여, 없는 행정동을 찾기
missing_dongs = dong_df[~dong_df["adm_nm"].isin(df["행정동"])]

# missing_dongs에 있는 행정동을 df에 추가하고, 나머지 column 값은 0으로 설정
for adm_nm in missing_dongs["adm_nm"]:
    # 새로운 행을 생성
    new_row = {col: 0 for col in df.columns}  # df의 모든 열에 대해 0으로 초기화
    new_row["행정동"] = adm_nm  # 행정동은 해당 행정동으로 설정
    
    # df에 새로운 행을 추가
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    
# 행정동을 가나다 순으로 정렬 (치안센터 수와 상관없이)
df = df.sort_values(by="행정동", key=lambda x: x.astype(str), ascending=True)
# 인덱스를 다시 설정
df = df.reset_index(drop=True)

print(df.head())

# CSV 파일로 저장
file_name = "찐찐통합_행정동별_치안센터.csv"
with open(file_name, mode="w", encoding="utf-8", newline="") as file:
    df.to_csv(file, index=False)


# # 정리된 데이터 저장
# df1.to_csv("업데이트된_행정동별_치안센터.csv", encoding="utf-8", index=False)

# print("파일이 성공적으로 저장되었습니다: 업데이트된_행정동별_치안센터.csv")
