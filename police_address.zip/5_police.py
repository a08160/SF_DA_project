import pandas as pd

# 
file_name = "통합_서울_치안센터_주소.csv"
df = pd.read_csv(file_name, encoding="euc-kr")

# '행정동' 컬럼의 값에서 양끝 공백 제거
df['행정동'] = df['행정동'].str.strip()

# '행정동'별 치안센터 개수 계산
df_count = df.groupby('행정동').size().reset_index(name='치안센터')

# '행정동'과 '치안센터' 컬럼만 남기기
df_count = df_count[['행정동', '치안센터']]

# 행정동을 가나다 순으로 정렬
df_count = df_count.sort_values(by='행정동', ascending=True)

# 결과 확인
print(df_count.head())

# 변경된 데이터프레임을 CSV 파일로 저장
output_file = "행정동별_치안센터.csv"

with open(output_file, mode="w", encoding="utf-8", newline="") as file:
    df_count.to_csv(file, index=False)

print(f"파일이 성공적으로 저장되었습니다: {output_file}")