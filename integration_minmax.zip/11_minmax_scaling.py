import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 엑셀 파일 불러오기
file_path = "최종_preprocessing_data.xlsx"
df = pd.read_excel(file_path)

# 세 번째 칼럼부터 마지막 칼럼까지 선택
columns_to_scale = df.columns[2:]  # 세 번째 칼럼부터 끝까지

# Min-Max Scaler 설정 (최소 -1, 최대 1)
scaler = MinMaxScaler(feature_range=(-1, 1))

# 스케일링 적용
df_scaled = df.copy()  # 원본 유지
df_scaled[columns_to_scale] = scaler.fit_transform(df[columns_to_scale])

# 새로운 엑셀 파일로 저장
output_file_path = "minmaxscaled_preprocessing_data.xlsx"
df_scaled.to_excel(output_file_path, index=False)

print(f"스케일링 완료! 새로운 파일이 저장되었습니다: {output_file_path}")
