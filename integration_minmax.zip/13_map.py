import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 파일 로드
file_name = "찐막_preprocessing_data.xlsx"
df = pd.read_excel(file_name)

# "자치구", "행정동" 칼럼을 제외한 숫자 데이터 선택
fixed_columns = ["자치구", "행정동"]
data_columns = [col for col in df.columns if col not in fixed_columns]

# Min-Max 스케일링 (-1 ~ 1)
scaler = MinMaxScaler(feature_range=(-1, 1))
df[data_columns] = scaler.fit_transform(df[data_columns])

# 대분류(칼럼명에서 "-" 기준 왼쪽 문자열) 추출 후 정렬
df_sorted = df[fixed_columns + sorted(data_columns, key=lambda x: x.split("-")[0])]

# 엑셀 파일로 저장
output_file = "최종정렬_preprocessing_data.xlsx"
with pd.ExcelWriter(output_file, engine="xlsxwriter") as writer:
    df_sorted.to_excel(writer, index=False)

print(f"파일 저장 완료: {output_file}")
