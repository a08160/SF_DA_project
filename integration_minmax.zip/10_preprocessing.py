import pandas as pd

file_name = "preprocessing_data.xlsx"
df = pd.read_excel(file_name)

# 숫자로 변환 (컴마 제거 후 변환)
columns_to_convert = [
    "연립주택", "다세대주택", "단독주택-일반", "단독주택-다가구", "단독주택-영업겸용",
    "20~29세", "30~39세", "60~69세", "70~79세", "80~89세", "90~99세", "100세 이상",
    "슈퍼마켓_수", "편의점", "종합병원_수", "일반_병원_수", "문화예술회관", "문화원",
    "박물관/기념관", "미술관/갤러리","총 인구수"
]

# 컴마 제거 후 숫자로 변환
df[columns_to_convert] = df[columns_to_convert].apply(lambda x: x.astype(str).str.replace(",", "").astype(int))

# '연립주택'과 '다세대 주택' 합산 후 컬럼 추가
df["연립+다세대주택"] = df["연립주택"] + df["다세대주택"]
df.drop(columns=["연립주택", "다세대주택"], inplace=True)

# '독립주택' 컬럼 생성 및 기존 컬럼 삭제
df["독립주택"] = df["단독주택-일반"] + df["단독주택-다가구"] + df["단독주택-영업겸용"]
df.drop(columns=["단독주택-일반", "단독주택-다가구", "단독주택-영업겸용"], inplace=True)

# '청년층(2030)' 컬럼 생성 및 기존 컬럼 삭제
df["청년층(2030)"] = df["20~29세"] + df["30~39세"]
df.drop(columns=["20~29세", "30~39세"], inplace=True)

# '고령층(60이상)' 컬럼 생성 및 기존 컬럼 삭제
df["고령층(60이상)"] = df["60~69세"] + df["70~79세"] + df["80~89세"] + df["90~99세"] + df["100세 이상"]
df.drop(columns=["60~69세", "70~79세", "80~89세", "90~99세", "100세 이상"], inplace=True)

# '슈퍼+편의점' 컬럼 생성 및 기존 컬럼 삭제
df["슈퍼+편의점"] = df["슈퍼마켓_수"] + df["편의점"]
df.drop(columns=["슈퍼마켓_수", "편의점"], inplace=True)

# '병원' 컬럼 생성 및 기존 컬럼 삭제
df["병원"] = df["종합병원_수"] + df["일반_병원_수"]
df.drop(columns=["종합병원_수", "일반_병원_수"], inplace=True)

# '문화' 컬럼 생성 및 기존 컬럼 삭제
df["문화"] = df["문화예술회관"] + df["문화원"]
df.drop(columns=["문화예술회관", "문화원"], inplace=True)

# '전시' 컬럼 생성 및 기존 컬럼 삭제
df["전시"] = df["박물관/기념관"] + df["미술관/갤러리"]
df.drop(columns=["박물관/기념관", "미술관/갤러리"], inplace=True)

# 변경된 데이터를 엑셀 파일로 저장 (with 문 사용)
output_file = "찐막_preprocessing_data.xlsx"
with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
    df.to_excel(writer, index=False)

print(f"파일이 성공적으로 저장되었습니다: {output_file}")
