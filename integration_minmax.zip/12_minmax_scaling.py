import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 업로드된 파일 리스트
file_paths = {
    "동별_교육": "동별_교육.xlsx",
    "동별_교통": "동별_교통.xlsx",
    "동별_복지": "동별_복지.xlsx",
    "동별_생활편의시설": "동별_생활편의시설(상업_및_문화시설).xlsx",
    "동별_안전": "동별_안전.xlsx",
    "동별_주택": "동별_주택(주거환경).xlsx",
    "동별_지역인구": "동별_지역인구(인구_및_인구_구조).xlsx"
}

# Min-Max Scaler 설정 (최소 -1, 최대 1)
scaler = MinMaxScaler(feature_range=(-1, 1))

# 파일별 스케일링 적용 및 저장
for name, path in file_paths.items():
    # 엑셀 파일 불러오기
    df = pd.read_excel(path)
    
    # 세 번째 칼럼부터 마지막 칼럼까지 선택
    columns_to_scale = df.columns[2:]  
    
    # Min-Max Scaling 적용
    df_scaled = df.copy()
    df_scaled[columns_to_scale] = scaler.fit_transform(df[columns_to_scale])
    
    # 새로운 엑셀 파일 저장
    output_path = f"{name}_scaled.xlsx"
    df_scaled.to_excel(output_path, index=False)
    
    print(f"스케일링 완료: {output_path}")

print("모든 파일 변환이 완료되었습니다! 🚀")

